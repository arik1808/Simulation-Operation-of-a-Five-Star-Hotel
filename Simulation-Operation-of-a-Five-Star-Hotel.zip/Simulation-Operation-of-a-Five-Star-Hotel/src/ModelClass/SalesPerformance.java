
package ModelClass;


public class SalesPerformance {
    private String month;
   

    
    
    
    
    
    private int salserate;
    private int salesAmount;

    public int getSalserate() {
        return salserate;
    }

    public void setSalserate(int salserate) {
        this.salserate = salserate;
    }

     public int getSalesAmount() {
        return salesAmount;
    }

    public void setSalesAmount(int salesAmount) {
        this.salesAmount = salesAmount;
    
    
    
    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
}
    public SalesPerformance(String month, int salesAmount) {
        this.month = month;
        this.salesAmount = salesAmount;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getSalesAmount() {
        return salesAmount;
    }

    public void setSalesAmount(int salesAmount) {
        this.salesAmount = salesAmount;
    }
}

